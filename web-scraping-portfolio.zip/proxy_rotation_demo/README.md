# Proxy Rotation Demo (Python)

Small, focused examples of rotating proxies with **Requests** and **Selenium**, including health checks and exponential backoff.
