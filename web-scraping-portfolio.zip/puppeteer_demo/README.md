# Puppeteer Demo (Node.js)

Headless Chromium scraping with **proxy** and **stealth** plugin.

## Quickstart
```bash
cd puppeteer_demo
npm install
node index.js
```
