# Tests

Contains simple `pytest`-based tests for parsing helpers and HTML fixtures used by the Scrapy spider.
